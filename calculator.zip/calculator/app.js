function getNumber(num){
    var result = document.getElementById('result');
result.value += num;
    
}

function getClear(){
    var clear = document.getElementById('result');
    result.value = ""
}

function getResult(){
    var result = document.getElementById('result');
result.value = eval(result.value);
}
function getbackspace(){
    var getNumber = document.getElementById('result');
    var remove = getNumber.value;
    remove = remove.slice(0, -1);
    getNumber.value = remove;

}